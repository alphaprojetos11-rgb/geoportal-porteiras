declare namespace Cloudflare {
  interface Env {
    DB: D1Database;
    ORTHO_URL?: string;
  }
}
