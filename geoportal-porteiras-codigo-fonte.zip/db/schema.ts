export const createMeasurementsTable = `
  CREATE TABLE IF NOT EXISTS measurements (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL CHECK (type IN ('straight', 'path', 'area')),
    coordinates TEXT NOT NULL,
    value REAL NOT NULL,
    unit TEXT NOT NULL CHECK (unit IN ('m', 'm²')),
    segments TEXT NOT NULL DEFAULT '[]',
    created_at TEXT NOT NULL
  )
`;

export const createMeasurementsDateIndex = `
  CREATE INDEX IF NOT EXISTS idx_measurements_created_at
  ON measurements(created_at DESC)
`;
