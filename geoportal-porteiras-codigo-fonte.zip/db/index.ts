import { env } from 'cloudflare:workers';
import { createMeasurementsDateIndex, createMeasurementsTable } from './schema';

let initialized = false;

export async function getDb() {
  if (!env.DB) throw new Error('Banco compartilhado indisponível.');
  if (!initialized) {
    await env.DB.batch([
      env.DB.prepare(createMeasurementsTable),
      env.DB.prepare(createMeasurementsDateIndex),
    ]);
    initialized = true;
  }
  return env.DB;
}
