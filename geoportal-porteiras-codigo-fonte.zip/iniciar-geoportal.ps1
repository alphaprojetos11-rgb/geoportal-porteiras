$ErrorActionPreference = 'Stop'
$siteDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$qgisPython = 'C:\Program Files\QGIS 3.40.15\bin\python-qgis-ltr.bat'

if (-not (Test-Path -LiteralPath $qgisPython)) { throw 'QGIS 3.40.15 não foi encontrado neste computador.' }

$server = Start-Process -FilePath $qgisPython -ArgumentList @((Join-Path $siteDir 'tile_server.py')) -WorkingDirectory $siteDir -WindowStyle Hidden -PassThru
try {
    foreach ($attempt in 1..20) {
        try {
            if ((Invoke-WebRequest -UseBasicParsing 'http://127.0.0.1:8765/health' -TimeoutSec 1).StatusCode -eq 200) { break }
        }
        catch { Start-Sleep -Milliseconds 500 }
    }
    Start-Process 'http://127.0.0.1:8765' | Out-Null
    Write-Host 'Geoportal aberto. Feche esta janela para encerrar.'
    Wait-Process -Id $server.Id
}
finally {
    if ($server -and -not $server.HasExited) { Stop-Process -Id $server.Id }
}
