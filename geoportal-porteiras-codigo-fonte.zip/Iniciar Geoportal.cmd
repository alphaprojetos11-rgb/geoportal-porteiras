@echo off
setlocal
set "SITE_DIR=%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%SITE_DIR%iniciar-geoportal.ps1"
endlocal
