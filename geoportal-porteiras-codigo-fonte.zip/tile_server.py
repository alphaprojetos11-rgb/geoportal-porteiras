"""Serviço local de mosaicos: lê o ECW e entrega apenas os blocos visíveis."""

import json
import math
import mimetypes
import os
import re
import threading
import uuid
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

from osgeo import gdal, osr

HOST = "127.0.0.1"
PORT = 8765
ORTHO_PATH = os.environ.get(
    "PORTEIRAS_ECW",
    r"E:\QGIS\BASE DE DADOS\ORTOMOSAICOS\ECW PORTEIRAS.ecw",
)
ROOT = Path(__file__).resolve().parent
CACHE = ROOT / "local-cache" / "tiles"
STATIC = ROOT / "web"
MEASUREMENTS_FILE = ROOT / "measurements.json"
MEASUREMENTS_LOCK = threading.RLock()
TILE_RE = re.compile(r"^/tiles/(\d{1,2})/(\d+)/(\d+)\.jpg$")
WEB_MERCATOR_LIMIT = 20037508.342789244
GDAL_LOCK = threading.RLock()

gdal.UseExceptions()
gdal.SetConfigOption("GDAL_NUM_THREADS", "1")
DATASET = gdal.Open(ORTHO_PATH, gdal.GA_ReadOnly)
if DATASET is None:
    raise RuntimeError(f"Não foi possível abrir a ortofoto: {ORTHO_PATH}")


def source_extent_3857():
    gt = DATASET.GetGeoTransform()
    source = osr.SpatialReference()
    source.ImportFromWkt(DATASET.GetProjection())
    source.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    target = osr.SpatialReference()
    target.ImportFromEPSG(3857)
    target.SetAxisMappingStrategy(osr.OAMS_TRADITIONAL_GIS_ORDER)
    transform = osr.CoordinateTransformation(source, target)
    corners = []
    for px, py in ((0, 0), (DATASET.RasterXSize, 0), (0, DATASET.RasterYSize), (DATASET.RasterXSize, DATASET.RasterYSize)):
        x = gt[0] + px * gt[1] + py * gt[2]
        y = gt[3] + px * gt[4] + py * gt[5]
        tx, ty, _ = transform.TransformPoint(x, y)
        corners.append((tx, ty))
    xs, ys = zip(*corners)
    return min(xs), min(ys), max(xs), max(ys)


ORTHO_EXTENT = source_extent_3857()


def tile_bounds(z, x, y):
    world = WEB_MERCATOR_LIMIT * 2
    span = world / (2 ** z)
    min_x = -WEB_MERCATOR_LIMIT + x * span
    max_x = min_x + span
    max_y = WEB_MERCATOR_LIMIT - y * span
    min_y = max_y - span
    return min_x, min_y, max_x, max_y


def intersects(a, b):
    return not (a[2] <= b[0] or a[0] >= b[2] or a[3] <= b[1] or a[1] >= b[3])


def render_tile(z, x, y, destination):
    bounds = tile_bounds(z, x, y)
    if not intersects(bounds, ORTHO_EXTENT):
        return None
    destination.parent.mkdir(parents=True, exist_ok=True)
    temporary = destination.with_suffix(".tmp")
    with GDAL_LOCK:
        warped = gdal.Warp(
            "",
            DATASET,
            format="MEM",
            dstSRS="EPSG:3857",
            outputBounds=bounds,
            width=256,
            height=256,
            resampleAlg=gdal.GRA_Bilinear,
            multithread=False,
        )
        if warped is None:
            return None
        output = gdal.Translate(str(temporary), warped, format="JPEG", creationOptions=["QUALITY=88"])
        output = None
        warped = None
        data = temporary.read_bytes()
    temporary.replace(destination)
    return data


class Handler(BaseHTTPRequestHandler):
    server_version = "GeoportalPorteiras/1.0"

    def end_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Cache-Control", "public, max-age=604800")
        super().end_headers()

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_header("Access-Control-Allow-Methods", "GET, OPTIONS")
        self.end_headers()

    def do_GET(self):
        path = urlparse(self.path).path
        if path == "/api/config":
            self.send_json({"orthoUrl": None})
            return
        if path == "/api/measurements":
            with MEASUREMENTS_LOCK:
                measurements = json.loads(MEASUREMENTS_FILE.read_text("utf-8")) if MEASUREMENTS_FILE.exists() else []
            self.send_json({"measurements": measurements})
            return
        if path == "/health":
            self.send_json({
                "status": "ok",
                "arquivo": Path(ORTHO_PATH).name,
                "epsg": 31984,
                "resolucao": "0.0252808 m",
            })
            return

        match = TILE_RE.match(path)
        if match:
            z, x, y = map(int, match.groups())
            if z < 0 or z > 22 or x >= 2 ** z or y >= 2 ** z:
                self.send_error(404)
                return
            tile_path = CACHE / str(z) / str(x) / f"{y}.jpg"
            try:
                data = tile_path.read_bytes() if tile_path.exists() else render_tile(z, x, y, tile_path)
                if data is None:
                    self.send_response(204)
                    self.end_headers()
                    return
                self.send_response(200)
                self.send_header("Content-Type", "image/jpeg")
                self.send_header("Content-Length", str(len(data)))
                self.end_headers()
                self.wfile.write(data)
            except Exception as error:
                print(f"Falha ao gerar {z}/{x}/{y}: {error}")
                self.send_error(500)
            return

        relative = "index.html" if path == "/" else unquote(path).lstrip("/")
        requested = (STATIC / relative).resolve()
        static_root = STATIC.resolve()
        if requested != static_root and static_root not in requested.parents:
            self.send_error(403)
            return
        if not requested.is_file():
            self.send_error(404)
            return
        data = requested.read_bytes()
        content_type = mimetypes.guess_type(requested.name)[0] or "application/octet-stream"
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        path = urlparse(self.path).path
        if path != "/api/measurements":
            self.send_error(404)
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if length <= 0 or length > 131072:
                raise ValueError("Tamanho inválido")
            item = json.loads(self.rfile.read(length).decode("utf-8"))
            name = str(item.get("name", "")).strip()[:80]
            kind = item.get("type")
            coordinates = item.get("coordinates")
            value = float(item.get("value"))
            unit = item.get("unit")
            segments = item.get("segments", [])
            if not name or kind not in {"straight", "path", "area"} or unit not in {"m", "m²"}:
                raise ValueError("Medição inválida")
            if not isinstance(coordinates, list) or not 2 <= len(coordinates) <= 200:
                raise ValueError("Geometria inválida")
            measurement = {
                "id": str(uuid.uuid4()), "name": name, "type": kind,
                "coordinates": coordinates, "value": value, "unit": unit,
                "segments": segments,
                "created_at": datetime.now(timezone.utc).isoformat(),
            }
            with MEASUREMENTS_LOCK:
                measurements = json.loads(MEASUREMENTS_FILE.read_text("utf-8")) if MEASUREMENTS_FILE.exists() else []
                measurements.insert(0, measurement)
                temporary = MEASUREMENTS_FILE.with_suffix(".tmp")
                temporary.write_text(json.dumps(measurements[:200], ensure_ascii=False), "utf-8")
                temporary.replace(MEASUREMENTS_FILE)
            self.send_json({"measurement": measurement}, 201)
        except Exception as error:
            self.send_json({"error": str(error)}, 400)

    def send_json(self, value, status=200):
        payload = json.dumps(value, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def log_message(self, format, *args):
        if args and str(args[1]) not in {"200", "204"}:
            super().log_message(format, *args)


if __name__ == "__main__":
    CACHE.mkdir(parents=True, exist_ok=True)
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    server.daemon_threads = True
    print(f"Geoportal disponível em http://{HOST}:{PORT}")
    print("Mantenha esta janela aberta enquanto utilizar o Geoportal.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()
