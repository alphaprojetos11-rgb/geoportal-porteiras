'use client';

import { useEffect, useRef, useState } from 'react';
import type * as Leaflet from 'leaflet';
import proj4 from 'proj4';

const ORTHO_BOUNDS: [[number, number], [number, number]] = [[-7.5444797, -39.1295388], [-7.5252784, -39.1014556]];
const UTM_24S = '+proj=utm +zone=24 +south +ellps=GRS80 +units=m +no_defs';
type Mode = 'straight' | 'path' | 'area';
type Point = [number, number];
type Measurement = { id: string; name: string; type: Mode; coordinates: Point[]; value: number; unit: 'm' | 'm²'; segments: number[]; created_at: string };
type Draft = Omit<Measurement, 'id' | 'name' | 'created_at'>;

export default function Home() {
  const mapNode = useRef<HTMLDivElement>(null);
  const mapRef = useRef<Leaflet.Map | null>(null);
  const leafletRef = useRef<typeof Leaflet | null>(null);
  const layersRef = useRef<Record<'ortho' | 'satellite' | 'roads', Leaflet.Layer> | null>(null);
  const draftGroupRef = useRef<Leaflet.LayerGroup | null>(null);
  const savedGroupRef = useRef<Leaflet.LayerGroup | null>(null);
  const pointsRef = useRef<Point[]>([]);
  const modeRef = useRef<Mode | null>(null);
  const [ready, setReady] = useState(false);
  const [serviceOnline, setServiceOnline] = useState(false);
  const [panelOpen, setPanelOpen] = useState(true);
  const [savedOpen, setSavedOpen] = useState(false);
  const [coords, setCoords] = useState<Point>([-7.5349, -39.1155]);
  const [coordMode, setCoordMode] = useState<'decimal' | 'utm'>('decimal');
  const [visible, setVisible] = useState({ ortho: true, satellite: true, roads: false });
  const [opacity, setOpacity] = useState(100);
  const [measureMode, setMeasureMode] = useState<Mode | null>(null);
  const [draft, setDraft] = useState<Draft | null>(null);
  const [measureName, setMeasureName] = useState('');
  const [saved, setSaved] = useState<Measurement[]>([]);
  const [saving, setSaving] = useState(false);

  const loadMeasurements = async () => {
    try {
      const response = await fetch('/api/measurements');
      if (response.ok) setSaved((await response.json()).measurements || []);
    } catch { /* o modo local pode iniciar sem banco compartilhado */ }
  };

  useEffect(() => {
    let active = true;
    Promise.all([import('leaflet'), fetch('/api/config').then((response) => response.ok ? response.json() : { orthoUrl: null }).catch(() => ({ orthoUrl: null }))]).then(async ([L, config]) => {
      if (!active || !mapNode.current || mapRef.current) return;
      leafletRef.current = L;
      const map = L.map(mapNode.current, { zoomControl: false, minZoom: 11, maxZoom: 23, doubleClickZoom: false });
      map.fitBounds(ORTHO_BOUNDS, { padding: [30, 30] });
      const satellite = L.tileLayer('https://mt1.google.com/vt/lyrs=s&x={x}&y={y}&z={z}', { maxZoom: 22, zIndex: 100, attribution: 'Imagens © Google' }).addTo(map);
      let ortho: Leaflet.Layer;
      if (config.orthoUrl) {
        const { PMTiles, leafletRasterLayer } = await import('pmtiles');
        ortho = leafletRasterLayer(new PMTiles(config.orthoUrl), { attribution: 'Ortofoto municipal de Porteiras' });
        ortho.addTo(map);
      } else {
        const host = window.location.port === '8765' ? window.location.origin : 'http://127.0.0.1:8765';
        ortho = L.tileLayer(`${host}/tiles/{z}/{x}/{y}.jpg`, { minZoom: 11, maxZoom: 23, zIndex: 300, bounds: L.latLngBounds(ORTHO_BOUNDS), attribution: 'Ortofoto municipal de Porteiras' }).addTo(map);
        fetch(`${host}/health`).then((response) => setServiceOnline(response.ok)).catch(() => setServiceOnline(false));
      }
      if (config.orthoUrl) setServiceOnline(true);
      const roads = L.tileLayer('https://mt1.google.com/vt/lyrs=h&x={x}&y={y}&z={z}', { maxZoom: 22, zIndex: 400, attribution: 'Dados cartográficos © Google' });
      L.control.zoom({ position: 'bottomright' }).addTo(map);
      L.control.scale({ imperial: false, position: 'bottomleft' }).addTo(map);
      draftGroupRef.current = L.layerGroup().addTo(map);
      savedGroupRef.current = L.layerGroup().addTo(map);
      layersRef.current = { ortho, satellite, roads };
      mapRef.current = map;
      map.on('mousemove', (event) => setCoords([event.latlng.lat, event.latlng.lng]));
      map.on('click', (event) => {
        setCoords([event.latlng.lat, event.latlng.lng]);
        if (!modeRef.current) return;
        pointsRef.current = [...pointsRef.current, [event.latlng.lat, event.latlng.lng]];
        drawDraft(modeRef.current, pointsRef.current);
        if (modeRef.current === 'straight' && pointsRef.current.length === 2) finishMeasurement('straight');
      });
      setReady(true);
      loadMeasurements();
    });
    return () => { active = false; mapRef.current?.remove(); mapRef.current = null; };
  }, []);

  useEffect(() => {
    if (!ready || !mapRef.current || !layersRef.current) return;
    (Object.keys(visible) as Array<keyof typeof visible>).forEach((key) => {
      const layer = layersRef.current![key];
      if (visible[key] && !mapRef.current!.hasLayer(layer)) layer.addTo(mapRef.current!);
      if (!visible[key] && mapRef.current!.hasLayer(layer)) layer.remove();
    });
  }, [visible, ready]);

  useEffect(() => {
    const layer = layersRef.current?.ortho as Leaflet.TileLayer | undefined;
    layer?.setOpacity?.(opacity / 100);
  }, [opacity]);

  useEffect(() => {
    const L = leafletRef.current, group = savedGroupRef.current;
    if (!L || !group) return;
    group.clearLayers();
    saved.forEach((item) => {
      const style = { color: item.type === 'area' ? '#d99142' : '#2e735f', weight: 4, fillOpacity: .16 };
      const layer = item.type === 'area' ? L.polygon(item.coordinates, style) : L.polyline(item.coordinates, style);
      layer.bindPopup(`<strong>${escapeHtml(item.name)}</strong><br>${formatMeasure(item.value, item.unit)}`);
      layer.addTo(group);
    });
  }, [saved]);

  const drawDraft = (mode: Mode, points: Point[]) => {
    const L = leafletRef.current, group = draftGroupRef.current;
    if (!L || !group) return;
    group.clearLayers();
    if (points.length > 1) {
      if (mode === 'area') L.polygon(points, { color: '#ef9c42', weight: 3, fillOpacity: .2, dashArray: '7 7' }).addTo(group);
      else L.polyline(points, { color: '#ef9c42', weight: 4, dashArray: mode === 'path' ? '8 6' : undefined }).addTo(group);
    }
    points.forEach((point, index) => {
      L.circleMarker(point, { radius: 5, color: '#fff', weight: 2, fillColor: '#ef9c42', fillOpacity: 1 }).addTo(group);
      if (index > 0) {
        const segment = distanceMeters(points[index - 1], point);
        const mid: Point = [(points[index - 1][0] + point[0]) / 2, (points[index - 1][1] + point[1]) / 2];
        L.marker(mid, { interactive: false, icon: L.divIcon({ className: 'segment-label', html: `${segment.toFixed(2)} m` }) }).addTo(group);
      }
    });
  };

  const startMeasurement = (mode: Mode) => {
    draftGroupRef.current?.clearLayers();
    pointsRef.current = [];
    modeRef.current = mode;
    setMeasureMode(mode);
    setDraft(null);
    setMeasureName('');
  };

  const finishMeasurement = (forcedMode?: Mode) => {
    const mode = forcedMode || modeRef.current;
    const points = pointsRef.current;
    if (!mode || points.length < (mode === 'area' ? 3 : 2)) return;
    const segments = points.slice(1).map((point, index) => distanceMeters(points[index], point));
    const value = mode === 'area' ? polygonArea(points) : segments.reduce((sum, segment) => sum + segment, 0);
    setDraft({ type: mode, coordinates: [...points], segments, value, unit: mode === 'area' ? 'm²' : 'm' });
    modeRef.current = null;
    setMeasureMode(null);
  };

  const cancelMeasurement = () => {
    modeRef.current = null; pointsRef.current = []; draftGroupRef.current?.clearLayers();
    setMeasureMode(null); setDraft(null); setMeasureName('');
  };

  const saveMeasurement = async () => {
    if (!draft || !measureName.trim()) return;
    setSaving(true);
    try {
      const response = await fetch('/api/measurements', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ ...draft, name: measureName.trim() }) });
      if (!response.ok) throw new Error('Falha ao salvar');
      const { measurement } = await response.json();
      setSaved((current) => [measurement, ...current]);
      cancelMeasurement();
      setSavedOpen(true);
    } finally { setSaving(false); }
  };

  const showSaved = (item: Measurement) => {
    const map = mapRef.current, L = leafletRef.current;
    if (!map || !L) return;
    map.fitBounds(L.latLngBounds(item.coordinates), { padding: [50, 50], maxZoom: 21 });
  };

  const toggle = (layer: keyof typeof visible) => setVisible((current) => ({ ...current, [layer]: !current[layer] }));

  return (
    <main className={`app-shell ${panelOpen ? '' : 'panel-closed'}`}>
      <header className="topbar">
        <div className="brand-mark">PG</div><div><p className="eyebrow">Porteiras · Ceará</p><h1>Geoportal Municipal</h1></div>
        <div className="header-actions"><button className="saved-button" onClick={() => setSavedOpen(!savedOpen)}>⌁ Medições salvas <b>{saved.length}</b></button><div className={`status-pill ${serviceOnline ? '' : 'offline'}`}><span /> {serviceOnline ? 'Ortofoto conectada' : 'Serviço indisponível'}</div></div>
      </header>

      <aside className="layer-panel" aria-label="Controle de camadas">
        <div className="panel-heading"><div><p className="eyebrow">Visualização</p><h2>Camadas do mapa</h2></div><button onClick={() => setPanelOpen(false)} aria-label="Recolher painel">×</button></div>
        <p className="panel-copy">Ative, desative e ajuste as camadas exibidas sobre o território.</p>
        <LayerCard icon="▦" iconClass="ortho" title="Ortofoto Porteiras" subtitle="Imagem municipal · 2,5 cm/pixel" active={visible.ortho} onToggle={() => toggle('ortho')}>
          <label htmlFor="ortho-opacity">Opacidade <span>{opacity}%</span></label><input id="ortho-opacity" type="range" min="0" max="100" value={opacity} onChange={(event) => setOpacity(Number(event.target.value))} />
        </LayerCard>
        <LayerCard icon="◫" iconClass="satellite" title="Google Satellite" subtitle="Imagem de referência" active={visible.satellite} onToggle={() => toggle('satellite')} />
        <LayerCard icon="⌁" iconClass="roads" title="Google Roads" subtitle="Rótulos e vias" active={visible.roads} onToggle={() => toggle('roads')} />
        <button className="fit-button" onClick={() => mapRef.current?.fitBounds(ORTHO_BOUNDS, { padding: [30, 30] })}>Enquadrar ortofoto</button>
        <div className="map-details"><span>EPSG: 31984</span><span>SIRGAS 2000</span></div>
      </aside>

      {!panelOpen && <button className="open-panel" onClick={() => setPanelOpen(true)}>☰ <span>Camadas</span></button>}
      <section className="map-wrap" aria-label="Mapa interativo de Porteiras">
        <div ref={mapNode} className={`map ${measureMode ? 'measuring' : ''}`} />
        <div className="measure-toolbar" aria-label="Ferramentas de medição">
          <span className="tool-title">Régua</span>
          <button className={measureMode === 'straight' ? 'active' : ''} onClick={() => startMeasurement('straight')} title="Medir linha reta">↔ <span>Linha</span></button>
          <button className={measureMode === 'path' ? 'active' : ''} onClick={() => startMeasurement('path')} title="Medir caminho">⌁ <span>Caminho</span></button>
          <button className={measureMode === 'area' ? 'active' : ''} onClick={() => startMeasurement('area')} title="Medir área">⬡ <span>Área</span></button>
          {measureMode && measureMode !== 'straight' && <button className="finish-tool" onClick={() => finishMeasurement()}>Finalizar</button>}
          {(measureMode || draft) && <button className="cancel-tool" onClick={cancelMeasurement}>Cancelar</button>}
        </div>

        <div className="coord-control"><button className={coordMode === 'decimal' ? 'active' : ''} onClick={() => setCoordMode('decimal')}>Graus</button><button className={coordMode === 'utm' ? 'active' : ''} onClick={() => setCoordMode('utm')}>UTM</button><output>{formatCoordinates(coords, coordMode)}</output></div>
        {draft && <div className="save-measure"><p className="eyebrow">Medição concluída</p><strong>{formatMeasure(draft.value, draft.unit)}</strong>{draft.segments.length > 1 && <small>{draft.segments.map((segment, index) => `Trecho ${index + 1}: ${segment.toFixed(2)} m`).join(' · ')}</small>}<input value={measureName} maxLength={80} onChange={(event) => setMeasureName(event.target.value)} placeholder="Nome da medição" aria-label="Nome da medição" /><button disabled={!measureName.trim() || saving} onClick={saveMeasurement}>{saving ? 'Salvando…' : 'Salvar para todos'}</button></div>}
      </section>

      <aside className={`saved-drawer ${savedOpen ? 'open' : ''}`} aria-label="Medições salvas"><div className="saved-heading"><div><p className="eyebrow">Compartilhadas</p><h2>Medições salvas</h2></div><button onClick={() => setSavedOpen(false)}>×</button></div>{saved.length === 0 ? <p className="empty-state">Nenhuma medição salva ainda.</p> : <div className="saved-list">{saved.map((item) => <button key={item.id} onClick={() => showSaved(item)}><span className={`saved-kind ${item.type}`}>{item.type === 'area' ? '⬡' : item.type === 'path' ? '⌁' : '↔'}</span><span><strong>{item.name}</strong><small>{formatMeasure(item.value, item.unit)} · {new Date(item.created_at).toLocaleDateString('pt-BR')}</small></span></button>)}</div>}</aside>
    </main>
  );
}

function LayerCard({ icon, iconClass, title, subtitle, active, onToggle, children }: { icon: string; iconClass: string; title: string; subtitle: string; active: boolean; onToggle: () => void; children?: React.ReactNode }) {
  return <section className={`layer-card ${active ? 'selected' : ''}`}><button className="layer-row" onClick={onToggle} aria-pressed={active}><span className={`layer-icon ${iconClass}`}>{icon}</span><span className="layer-text"><strong>{title}</strong><small>{subtitle}</small></span><span className={`toggle ${active ? 'on' : ''}`} /></button>{children}</section>;
}

function toUtm(point: Point) { return proj4('EPSG:4326', UTM_24S, [point[1], point[0]]); }
function distanceMeters(a: Point, b: Point) { const pa = toUtm(a), pb = toUtm(b); return Math.hypot(pb[0] - pa[0], pb[1] - pa[1]); }
function polygonArea(points: Point[]) { const projected = points.map(toUtm); return Math.abs(projected.reduce((sum, point, index) => { const next = projected[(index + 1) % projected.length]; return sum + point[0] * next[1] - next[0] * point[1]; }, 0) / 2); }
function formatMeasure(value: number, unit: 'm' | 'm²') { return `${value.toLocaleString('pt-BR', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} ${unit}`; }
function formatCoordinates(point: Point, mode: 'decimal' | 'utm') { if (mode === 'decimal') return `${point[0].toFixed(6)}°, ${point[1].toFixed(6)}°`; const [e, n] = toUtm(point); return `E ${e.toFixed(2)} m · N ${n.toFixed(2)} m · 24S`; }
function escapeHtml(value: string) { return value.replace(/[&<>'"]/g, (character) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', "'": '&#39;', '"': '&quot;' })[character]!); }
