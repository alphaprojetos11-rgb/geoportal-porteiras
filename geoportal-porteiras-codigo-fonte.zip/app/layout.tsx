import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  metadataBase: new URL('http://localhost:3000'),
  title: 'Geoportal Municipal de Porteiras',
  description: 'WebGIS para consulta da ortofoto municipal de Porteiras, Ceará.',
  openGraph: {
    title: 'Geoportal Municipal de Porteiras',
    description: 'Ortofoto municipal e camadas de referência.',
    images: ['/og.png'],
    locale: 'pt_BR',
    type: 'website',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Geoportal Municipal de Porteiras',
    description: 'Ortofoto municipal e camadas de referência.',
    images: ['/og.png'],
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="pt-BR"><body>{children}</body></html>;
}
