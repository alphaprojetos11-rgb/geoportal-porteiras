import { env } from 'cloudflare:workers';

export const runtime = 'edge';

export async function GET() {
  return Response.json({ orthoUrl: env.ORTHO_URL || null });
}
