import { getDb } from '../../../db';

export const runtime = 'edge';

type MeasurementInput = {
  name?: unknown;
  type?: unknown;
  coordinates?: unknown;
  value?: unknown;
  unit?: unknown;
  segments?: unknown;
};

export async function GET() {
  const db = await getDb();
  const result = await db.prepare(`
    SELECT id, name, type, coordinates, value, unit, segments, created_at
    FROM measurements ORDER BY created_at DESC LIMIT 200
  `).all();
  const measurements = result.results.map((row) => ({
    ...row,
    coordinates: JSON.parse(String(row.coordinates)),
    segments: JSON.parse(String(row.segments)),
  }));
  return Response.json({ measurements });
}

export async function POST(request: Request) {
  const body = await request.json() as MeasurementInput;
  const name = typeof body.name === 'string' ? body.name.trim().slice(0, 80) : '';
  const type = body.type;
  const coordinates = body.coordinates;
  const value = Number(body.value);
  const unit = body.unit;
  const segments = Array.isArray(body.segments) ? body.segments.map(Number) : [];
  if (!name || !['straight', 'path', 'area'].includes(String(type))) return Response.json({ error: 'Nome ou tipo inválido.' }, { status: 400 });
  if (!Array.isArray(coordinates) || coordinates.length < 2 || coordinates.length > 200) return Response.json({ error: 'Geometria inválida.' }, { status: 400 });
  if (!coordinates.every((point) => Array.isArray(point) && point.length === 2 && point.every(Number.isFinite))) return Response.json({ error: 'Coordenadas inválidas.' }, { status: 400 });
  if (!Number.isFinite(value) || value < 0 || !['m', 'm²'].includes(String(unit))) return Response.json({ error: 'Medida inválida.' }, { status: 400 });
  if (segments.length > 199 || !segments.every(Number.isFinite)) return Response.json({ error: 'Segmentos inválidos.' }, { status: 400 });

  const measurement = {
    id: crypto.randomUUID(), name, type: String(type), coordinates,
    value, unit: String(unit), segments, created_at: new Date().toISOString(),
  };
  const db = await getDb();
  await db.prepare(`
    INSERT INTO measurements (id, name, type, coordinates, value, unit, segments, created_at)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).bind(
    measurement.id, measurement.name, measurement.type,
    JSON.stringify(measurement.coordinates), measurement.value,
    measurement.unit, JSON.stringify(measurement.segments), measurement.created_at,
  ).run();
  return Response.json({ measurement }, { status: 201 });
}
